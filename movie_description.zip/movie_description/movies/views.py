from django.shortcuts import render
import imdb
# Create your views here.

def index(request):
    if request.method=='POST':
        name=request.POST.get('movieName')
        ia = imdb.IMDb()
        search = ia.search_movie(name)
        year = search[0]['year']
        title = search[0]['title']
        id = search[0].movieID
        cast = ia.get_movie(id)
        l1 = cast['cast']
        string = ''
        for i in range(0, len(l1)):
            if i == len(l1) - 1:
                string += l1[i]['name'] + '.'
                break
            string += l1[i]['name'] + ' , '
        the_matrix = ia.get_movie(id)
        for director in the_matrix['directors']:
            dirName=director['name']
        lang = cast.guessLanguage()
        return render(request,'index.html',{'title':title,"year":year,'cast':string,'directorName':dirName,'language':lang})
    else:
        return render(request,'index.html')