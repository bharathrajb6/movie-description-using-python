from django.shortcuts import render
import imdb
# Create your views here.

def index(request):
    if request.method=='POST':
        name=request.POST.get('movieName')
        ia = imdb.IMDb()
        search = ia.search_movie(name)
        print(search)

        year = search[0]['year']
        print(year)

        title = search[0]['title']
        print(title)

        id = search[0].movieID
        print(id)

        cast = ia.get_movie(id)
        l1 = cast['cast']
        print(l1)
        string = ''
        for i in range(0, len(l1)):
            if i == len(l1) - 1:
                string += l1[i]['name'] + '.'
                break
            string += l1[i]['name'] + ' , '
        print(string)

        the_matrix = ia.get_movie(id)
        for director in the_matrix['directors']:
            dirName=director['name']
        lang = cast.guessLanguage()
        print(lang)
        return render(request,'index.html',{'title':title,"year":year,'cast':string,'directorName':dirName,'language':lang})
    else:
        return render(request,'index.html')